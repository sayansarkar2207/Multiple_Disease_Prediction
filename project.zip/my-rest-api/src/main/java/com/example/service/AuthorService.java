package com.example.service;

import com.example.model.Author;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class AuthorService {
    // Dummy database to store authors
    private static Map<Integer, Author> authorMap = new HashMap<>();
    private static int nextId = 1;

    // Get all authors
    public List<Author> getAllAuthors() {
        return new ArrayList<>(authorMap.values());
    }

    // Get author by ID
    public Author getAuthorById(int id) {
        return authorMap.get(id);
    }

    // Add a new author
    public Author addAuthor(Author author) {
        author.setId(nextId++);
        authorMap.put(author.getId(), author);
        return author;
    }

    // Update an existing author
    public Author updateAuthor(int id, Author updatedAuthor) {
        if (authorMap.containsKey(id)) {
            updatedAuthor.setId(id);
            authorMap.put(id, updatedAuthor);
            return updatedAuthor;
        } else {
            return null;
        }
    }

    // Delete an author by ID
    public boolean deleteAuthor(int id) {
        return authorMap.remove(id) != null;
    }
}
