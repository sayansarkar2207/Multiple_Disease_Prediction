package com.example.service;

import com.example.model.Borrower;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BorrowerService {
    // Dummy database to store borrowers
    private static Map<Integer, Borrower> borrowerMap = new HashMap<>();
    private static int nextId = 1;

    // Get all borrowers
    public List<Borrower> getAllBorrowers() {
        return new ArrayList<>(borrowerMap.values());
    }

    // Get borrower by ID
    public Borrower getBorrowerById(int id) {
        return borrowerMap.get(id);
    }

    // Add a new borrower
    public Borrower addBorrower(Borrower borrower) {
        borrower.setId(nextId++);
        borrowerMap.put(borrower.getId(), borrower);
        return borrower;
    }

    // Update an existing borrower
    public Borrower updateBorrower(int id, Borrower updatedBorrower) {
        if (borrowerMap.containsKey(id)) {
            updatedBorrower.setId(id);
            borrowerMap.put(id, updatedBorrower);
            return updatedBorrower;
        } else {
            return null;
        }
    }

    // Delete a borrower by ID
    public boolean deleteBorrower(int id) {
        return borrowerMap.remove(id) != null;
    }
}
