package com.example.service;

import com.example.model.Book;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class BookService {
    // Dummy database to store books
    private static Map<Integer, Book> bookMap = new HashMap<>();
    private static int nextId = 1;

    // Get all books
    public List<Book> getAllBooks() {
        return new ArrayList<>(bookMap.values());
    }

    // Get book by ID
    public Book getBookById(int id) {
        return bookMap.get(id);
    }

    // Add a new book
    public Book addBook(Book book) {
        book.setId(nextId++);
        bookMap.put(book.getId(), book);
        return book;
    }

    // Update an existing book
    public Book updateBook(int id, Book updatedBook) {
        if (bookMap.containsKey(id)) {
            updatedBook.setId(id);
            bookMap.put(id, updatedBook);
            return updatedBook;
        } else {
            return null;
        }
    }

    // Delete a book by ID
    public boolean deleteBook(int id) {
        return bookMap.remove(id) != null;
    }
}
