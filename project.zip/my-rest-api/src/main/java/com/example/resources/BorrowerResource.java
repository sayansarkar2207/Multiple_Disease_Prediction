package com.example.resources;

import com.example.model.Borrower;
import com.example.service.BorrowerService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.ws.rs.core.Response.Status;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

@OpenAPIDefinition(
        servers = {
                @Server(
                        url = "/library/api",
                        description = "Base URL for the API"
                )
        },
        tags = {
                @Tag(name = "Borrower Operations", description = "Rest endpoint for borrower operations")
        }
)
@Path("/borrowers")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "/borrowers", tags = "Borrower Operations")
@Tag(name = "Borrower Operations")
public class BorrowerResource {

    private final BorrowerService borrowerService;

    public BorrowerResource() {
        this.borrowerService = new BorrowerService(); // Instantiate the BorrowerService
    }

    @GET
    @ApiOperation(value = "Get all borrowers")
    @Operation(summary = "Get all borrowers", description = "Retrieve all borrowers from the system")
    public Response getAllBorrowers() {
        List<Borrower> borrowers = borrowerService.getAllBorrowers();
        return Response.ok(borrowers).build();
    }

    @GET
    @Path("/{id}")
    @ApiOperation(value = "Get borrower by ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = Borrower.class),
            @ApiResponse(code = 404, message = "Borrower not found")
    })
    @Operation(summary = "Get borrower by ID", description = "Retrieve a borrower with the specified ID")
    public Response getBorrowerById(@PathParam("id") int id) {
        Borrower borrower = borrowerService.getBorrowerById(id);
        if (borrower != null) {
            return Response.ok(borrower).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @POST
    @ApiOperation(value = "Add a new borrower")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Borrower added successfully", response = Borrower.class),
            @ApiResponse(code = 400, message = "Invalid input")
    })
    @Operation(summary = "Add a new borrower", description = "Add a new borrower to the system")
    public Response addBorrower(Borrower borrower) {
        Borrower addedBorrower = borrowerService.addBorrower(borrower);
        return Response.status(Response.Status.CREATED).entity(addedBorrower).build();
    }

    @PUT
    @Path("/{id}")
    @ApiOperation(value = "Update a borrower")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Borrower updated successfully", response = Borrower.class),
            @ApiResponse(code = 404, message = "Borrower not found")
    })
    @Operation(summary = "Update a borrower", description = "Update an existing borrower with the specified ID")
    public Response updateBorrower(@PathParam("id") int id, Borrower borrower) {
        Borrower updatedBorrower = borrowerService.updateBorrower(id, borrower);
        if (updatedBorrower != null) {
            return Response.ok(updatedBorrower).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @ApiOperation(value = "Delete a borrower")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Borrower deleted successfully"),
            @ApiResponse(code = 404, message = "Borrower not found")
    })
    @Operation(summary = "Delete a borrower", description = "Delete a borrower with the specified ID")
    public Response deleteBorrower(@PathParam("id") int id) {
        boolean deleted = borrowerService.deleteBorrower(id);
        if (deleted) {
            return Response.ok().build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }
}
