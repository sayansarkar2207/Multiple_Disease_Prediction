package com.example.resources;

import com.example.model.Book;
import com.example.service.BookService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

@OpenAPIDefinition(
        servers = {
                @Server(
                        url = "/library/api",
                        description = "Base URL for the API"
                )
        },
        tags = {
                @Tag(name = "Book Operations", description = "Rest endpoint for book operations")
        }
)
@Path("/books")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "/books", tags = "Book Operations")
@Tag(name = "Book Operations")
public class BookResource {

    private final BookService bookService;

    public BookResource() {
        this.bookService = new BookService(); // Instantiate the BookService
    }

    @GET
    @ApiOperation(value = "Get all books")
    @Operation(summary = "Get all books", description = "Retrieve all books from the library")
    public Response getAllBooks() {
        List<Book> books = bookService.getAllBooks();
        return Response.ok(books).build();
    }

    @GET
    @Path("/{id}")
    @ApiOperation(value = "Get book by ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = Book.class),
            @ApiResponse(code = 404, message = "Book not found")
    })
    @Operation(summary = "Get book by ID", description = "Retrieve a book with the specified ID")
    public Response getBookById(@PathParam("id") int id) {
        Book book = bookService.getBookById(id);
        if (book != null) {
            return Response.ok(book).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @POST
    @ApiOperation(value = "Add a new book")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Book added successfully", response = Book.class),
            @ApiResponse(code = 400, message = "Invalid input")
    })
    @Operation(summary = "Add a new book", description = "Add a new book to the library")
    public Response addBook(Book book) {
        Book addedBook = bookService.addBook(book);
        return Response.status(Response.Status.CREATED).entity(addedBook).build();
    }

    @PUT
    @Path("/{id}")
    @ApiOperation(value = "Update a book")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Book updated successfully", response = Book.class),
            @ApiResponse(code = 404, message = "Book not found")
    })
    @Operation(summary = "Update a book", description = "Update an existing book with the specified ID")
    public Response updateBook(@PathParam("id") int id, Book book) {
        Book updatedBook = bookService.updateBook(id, book);
        if (updatedBook != null) {
            return Response.ok(updatedBook).build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @ApiOperation(value = "Delete a book")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Book deleted successfully"),
            @ApiResponse(code = 404, message = "Book not found")
    })
    @Operation(summary = "Delete a book", description = "Delete a book with the specified ID")
    public Response deleteBook(@PathParam("id") int id) {
        boolean deleted = bookService.deleteBook(id);
        if (deleted) {
            return Response.ok().build();
        } else {
            return Response.status(Response.Status.NOT_FOUND).build();
        }
    }
}
