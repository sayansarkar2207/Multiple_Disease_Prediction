package com.example.resources;

import com.example.model.Author;
import com.example.service.AuthorService;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;
import java.util.List;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiResponse;
import io.swagger.annotations.ApiResponses;
import javax.ws.rs.core.Response.Status;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.servers.Server;
import io.swagger.v3.oas.annotations.tags.Tag;
import io.swagger.v3.oas.annotations.Operation;

@OpenAPIDefinition(
        servers = {
                @Server(
                        url = "/library/api",
                        description = "Base URL for the API"
                )
        },
        tags = {
                @Tag(name = "Author Operations", description = "Rest endpoint for author operations")
        }
)
@Path("/authors")
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
@Api(value = "/authors", tags = "Author Operations")
@Tag(name = "Author Operations")
public class AuthorResource {

    private final AuthorService authorService;

    public AuthorResource() {
        this.authorService = new AuthorService(); // Instantiate the AuthorService
    }

    @GET
    @ApiOperation(value = "Get all authors")
    @Operation(summary = "Get all authors", description = "Returns a list of all authors.")
    public Response getAllAuthors() {
        List<Author> authors = authorService.getAllAuthors();
        return Response.ok(authors).build();
    }

    @GET
    @Path("/{id}")
    @ApiOperation(value = "Get author by ID")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Success", response = Author.class),
            @ApiResponse(code = 404, message = "Author not found")
    })
    @Operation(summary = "Get author by ID", description = "Returns the author with the specified ID.")
    public Response getAuthorById(@PathParam("id") int id) {
        Author author = authorService.getAuthorById(id);
        if (author != null) {
            return Response.ok(author).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @POST
    @ApiOperation(value = "Add a new author")
    @ApiResponses(value = {
            @ApiResponse(code = 201, message = "Author added successfully", response = Author.class),
            @ApiResponse(code = 400, message = "Invalid input")
    })
    @Operation(summary = "Add a new author", description = "Adds a new author to the system.")
    public Response addAuthor(Author author) {
        Author addedAuthor = authorService.addAuthor(author);
        return Response.status(Response.Status.CREATED).entity(addedAuthor).build();
    }

    @PUT
    @Path("/{id}")
    @ApiOperation(value = "Update an author")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Author updated successfully", response = Author.class),
            @ApiResponse(code = 404, message = "Author not found")
    })
    @Operation(summary = "Update an author", description = "Updates an existing author with the specified ID.")
    public Response updateAuthor(@PathParam("id") int id, Author author) {
        Author updatedAuthor = authorService.updateAuthor(id, author);
        if (updatedAuthor != null) {
            return Response.ok(updatedAuthor).build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }

    @DELETE
    @Path("/{id}")
    @ApiOperation(value = "Delete an author")
    @ApiResponses(value = {
            @ApiResponse(code = 200, message = "Author deleted successfully"),
            @ApiResponse(code = 404, message = "Author not found")
    })
    @Operation(summary = "Delete an author", description = "Deletes an author with the specified ID.")
    public Response deleteAuthor(@PathParam("id") int id) {
        boolean deleted = authorService.deleteAuthor(id);
        if (deleted) {
            return Response.ok().build();
        } else {
            return Response.status(Status.NOT_FOUND).build();
        }
    }
}
