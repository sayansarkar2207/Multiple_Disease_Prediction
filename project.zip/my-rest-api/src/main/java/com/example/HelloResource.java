package com.example;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;

@Path("/hello")
@Api(value = "/hello", tags = "Hello Resource")
public class HelloResource {

    @GET
    @Produces(MediaType.TEXT_PLAIN)
    @ApiOperation(value = "Get a greeting message", notes = "Returns a greeting message 'Hello, world!'")
    public String hello() {
        return "Hello, world!";
    }
}
