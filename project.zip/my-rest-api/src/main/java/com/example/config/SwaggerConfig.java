package com.example.config;

import io.swagger.jaxrs.config.BeanConfig;
import javax.ws.rs.ApplicationPath;
import javax.ws.rs.core.Application;

@ApplicationPath("/api")
public class SwaggerConfig extends Application {

    public SwaggerConfig() {
        // Configure Swagger
        configureSwagger();
    }

    private void configureSwagger() {
        // Set the Swagger base path
        BeanConfig beanConfig = new BeanConfig();
        beanConfig.setVersion("2.0");
        beanConfig.setSchemes(new String[]{"http"});
        beanConfig.setHost("localhost:8080");
        beanConfig.setBasePath("/library/api"); // Adjust the base path according to your application
        beanConfig.setResourcePackage("com.example.resources");
        beanConfig.setPrettyPrint(true);
        beanConfig.setScan(true);
    }
}
